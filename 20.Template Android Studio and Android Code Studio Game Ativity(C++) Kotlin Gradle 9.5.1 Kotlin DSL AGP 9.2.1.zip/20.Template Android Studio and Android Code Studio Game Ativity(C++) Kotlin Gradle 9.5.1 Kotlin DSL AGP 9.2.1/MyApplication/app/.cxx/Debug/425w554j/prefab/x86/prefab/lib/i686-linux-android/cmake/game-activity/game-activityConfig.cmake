if(NOT TARGET game-activity::game-activity)
add_library(game-activity::game-activity STATIC IMPORTED)
set_target_properties(game-activity::game-activity PROPERTIES
    IMPORTED_LOCATION "C:/Users/Daniel/.gradle/caches/9.5.1/transforms/9d09cd4254162d72c9bf438de90747a5/transformed/games-activity-4.4.2/prefab/modules/game-activity/libs/android.x86/libgame-activity.a"
    INTERFACE_INCLUDE_DIRECTORIES "C:/Users/Daniel/.gradle/caches/9.5.1/transforms/9d09cd4254162d72c9bf438de90747a5/transformed/games-activity-4.4.2/prefab/modules/game-activity/include"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

if(NOT TARGET game-activity::game-activity_static)
add_library(game-activity::game-activity_static STATIC IMPORTED)
set_target_properties(game-activity::game-activity_static PROPERTIES
    IMPORTED_LOCATION "C:/Users/Daniel/.gradle/caches/9.5.1/transforms/9d09cd4254162d72c9bf438de90747a5/transformed/games-activity-4.4.2/prefab/modules/game-activity_static/libs/android.x86/libgame-activity_static.a"
    INTERFACE_INCLUDE_DIRECTORIES "C:/Users/Daniel/.gradle/caches/9.5.1/transforms/9d09cd4254162d72c9bf438de90747a5/transformed/games-activity-4.4.2/prefab/modules/game-activity_static/include"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

