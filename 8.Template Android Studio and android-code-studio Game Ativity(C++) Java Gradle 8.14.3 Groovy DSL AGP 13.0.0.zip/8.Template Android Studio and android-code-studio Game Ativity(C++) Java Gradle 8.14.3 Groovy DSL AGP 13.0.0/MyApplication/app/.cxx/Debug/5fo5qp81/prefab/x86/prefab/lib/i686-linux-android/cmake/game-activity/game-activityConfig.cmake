if(NOT TARGET game-activity::game-activity)
add_library(game-activity::game-activity STATIC IMPORTED)
set_target_properties(game-activity::game-activity PROPERTIES
    IMPORTED_LOCATION "C:/Users/USUARIO/.gradle/caches/8.14.3/transforms/9bce241afb877d60670c77ecb5f84af1/transformed/games-activity-4.0.0/prefab/modules/game-activity/libs/android.x86/libgame-activity.a"
    INTERFACE_INCLUDE_DIRECTORIES "C:/Users/USUARIO/.gradle/caches/8.14.3/transforms/9bce241afb877d60670c77ecb5f84af1/transformed/games-activity-4.0.0/prefab/modules/game-activity/include"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

if(NOT TARGET game-activity::game-activity_static)
add_library(game-activity::game-activity_static STATIC IMPORTED)
set_target_properties(game-activity::game-activity_static PROPERTIES
    IMPORTED_LOCATION "C:/Users/USUARIO/.gradle/caches/8.14.3/transforms/9bce241afb877d60670c77ecb5f84af1/transformed/games-activity-4.0.0/prefab/modules/game-activity_static/libs/android.x86/libgame-activity_static.a"
    INTERFACE_INCLUDE_DIRECTORIES "C:/Users/USUARIO/.gradle/caches/8.14.3/transforms/9bce241afb877d60670c77ecb5f84af1/transformed/games-activity-4.0.0/prefab/modules/game-activity_static/include"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

